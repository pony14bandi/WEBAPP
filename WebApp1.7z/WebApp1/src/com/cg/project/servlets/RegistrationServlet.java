package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public RegistrationServlet() {
        super();

    }

	
	public void init(ServletConfig config) throws ServletException {
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String username=request.getParameter("username");
		String email_id=request.getParameter("email_id");
		String password=request.getParameter("password");		
		String repassword=request.getParameter("re-enter password");
		String gender=request.getParameter("gender");
		String communication[]=request.getParameterValues("Communication");
		String Graduation=request.getParameter("Graduation");
		String DetailInformation=request.getParameter("Enter Detail Information");
		String resume=request.getParameter("Select Resume");
		writer.println("<font color= 'blue' size=5>");
		writer.println("firstname: " +firstname );
		writer.println("<br>");
		writer.println("lastname: " +lastname );
		writer.println("<br>");
		writer.println("username: " +username );
		writer.println("<br>");
		writer.println("password: " +password );
		writer.println("<br>");
		writer.println("re-entered password: " +repassword );
		writer.println("<br>");
		writer.println("gender: " +gender );
		writer.println("<br>");
		writer.println("communication: " +communication );
		writer.println("<br>");
		writer.println("DetailInformation: " +DetailInformation );
		writer.println("<br>");
		writer.println("resume: " +resume );
	
	}

}
