package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(SrvletConfig config)");
	}
	public void destroy() {
		System.out.println("destroy");
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service");
		PrintWriter writer = response.getWriter();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		writer.println("username" +username );
		writer.println("password" +password );
		if(username.equals("poornima")&&password.equals("pony"))
			writer.println("<font color= 'blue' size=10> Hello Pony</font>");
		else
			writer.println("<font color= 'red' size=10> Enter Correct Details </font>");
	
// 500 error
	if(!username.equals(password)) {
		PrintWriter writer1 = response.getWriter();
		String username1=request.getParameter("username");
		String password1=request.getParameter("password");
		writer1.println("<font color='red' size='2'>Username And Password doesnot match</font>");
		writer1.println("<br />");
		writer1.println("<font color='red' size='2'>Access Denied </font>");
		writer1.println("<br />");
		writer1.println("<font color='red' size='2'>username:</font>"+username1+"<font color='red' size='2'>,with your Password: </font>"+password1);
	}
		
		
		
	
	if(username.equals("admin")&&password.equals("123")) {
		PrintWriter writer1 = response.getWriter();
		String username1=request.getParameter("username");
		String password1=request.getParameter("password");
		writer1.println("<font color='green' size='2'>Welcome Admin</font>");
		}
		
	}
}
